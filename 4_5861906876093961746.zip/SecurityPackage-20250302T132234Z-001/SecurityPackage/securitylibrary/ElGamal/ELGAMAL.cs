﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary.ElGamal
{
    public class ElGamal
    {
        private int ModPower(int baseNum, int exponent, int mod)
        {
            int result = 1;
            baseNum = baseNum % mod;

            while (exponent > 0)
            {
                if ((exponent & 1) == 1)
                    result = (result * baseNum) % mod;

                exponent = exponent >> 1;
                baseNum = (baseNum * baseNum) % mod;
            }

            return result;
        }

        private int ModInverse(int a, int mod)
        {
            for (int i = 1; i < mod; i++)
            {
                if ((a * i) % mod == 1)
                    return i;
            }
            throw new Exception("No modular inverse found.");
        }

        public List<long> Encrypt(int q, int alpha, int y, int k, int m)
        {
            List<long> cipher = new List<long>();

            long c1 = ModPower(alpha, k, q);
            long c2 = (m * ModPower(y, k, q)) % q;

            cipher.Add(c1);
            cipher.Add(c2);

            return cipher;
        }

        public int Decrypt(int c1, int c2, int x, int q)
        {
            int s = ModPower(c1, x, q);
            int sInverse = ModInverse(s, q);
            int m = (c2 * sInverse) % q;

            return m;
        }
    }
}